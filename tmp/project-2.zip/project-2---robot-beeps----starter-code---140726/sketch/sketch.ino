/**** INCLUDES *********************/
#include <Arduino_RouterBridge.h>

/**** GLOBALS **********************/
const byte PIEZO_PIN = A3; 

/**** FUNCTIONS ********************/

/*************************************************************
This function expects a vector of vectors.
The inner vectors are of form (frequency, duration, interval)

Example: ((880,50,10),(440,50,10),(880,50,10),(294,400,0))
*************************************************************/
void playSounds(MsgPack::arr_t<MsgPack::arr_t<int>> notes) {

  for(const auto& note : notes){

      int frequency = note[0];
      int duration = note[1];
      int interval = note[2];
      tone(PIEZO_PIN, frequency, duration);
      delay(duration + interval);
  }
}

/**** SETUP ************************/
void setup() {

    /************************************************/
    /** ADD BRIDGE CODE BELOW ***********************/
    /*⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇⬇*/
    

    /*⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆⬆*/
    /** ADD BRIDGE CODE ABOVE *********************/
    /************************************************/
    
}

/**** LOOP *************************/
void loop() {

}
